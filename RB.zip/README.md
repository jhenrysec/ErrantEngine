# TrainTracks

**An offline ICS/SCADA movable-bridge cyber range for the Donovia Rail Network scenario.**

TrainTracks is a self-contained, zero-dependency training environment that teaches how a
network command actually reaches — and breaks — the mechanical guts of a movable railroad
bridge. It pairs a dispatcher-scale rail HMI with a subsystem-level mechanical + Modbus trainer,
wires them together with live state sync, and ships a set of guided attack scenarios mapped to
MITRE ATT&CK for ICS. Built for 17C (Cyber Operations Specialist) instruction in an air-gapped lab.

The name cuts both ways: the railroad runs on tracks, and the whole point of the exercise is to
learn what an operator can **track** — the anomalous coil write, the stall current with no motion,
the lock that reports released while it's physically engaged.

![License](https://img.shields.io/badge/license-MIT-blue)
![Offline](https://img.shields.io/badge/network-air-gapped%20%2F%20offline-00e676)
![Dependencies](https://img.shields.io/badge/dependencies-none-success)
![Framework](https://img.shields.io/badge/stack-vanilla%20HTML%2FJS%2FSVG-131d2a)

---

## Why it exists

Most ICS demos stop at "an attacker can flip a bit." TrainTracks goes one layer down: every bit maps
to a real subsystem — a trunnion, a span lock, an end-lift jack — and out-of-sequence commands
produce the *mechanical* consequences they would in the field. Students stop thinking of a bridge as
a single open/closed flag and start reasoning about the choreography of interlocks that keep the span
either safe-for-rail or safe-for-marine, and never in between.

The recurring thesis, drilled across every scenario: **the HMI is not a security boundary, and
safety-critical interlocks must not live solely in a network-reachable PLC.**

---

## What's in the box

| File | Role |
|---|---|
| `index.html` | Launcher. Links to both apps. |
| `rail.html` | **Donovia Rail Network Control** — dispatcher HMI. Live map of trains, switches, signals, and all 8 movable bridges. |
| `trainer.html` | **Bridge Mechanical & SCADA Trainer** — Congaree (bascule) and Cooper (swing) at subsystem fidelity, with a Modbus map, network console, and attack scenarios. |
| `docs/BRIDGE-MECHANICAL-ANALYSIS.md` | Engineering + cyber reference: bascule vs swing mechanics, correct operating sequences, failure modes, control-system mapping, detection & defense. |
| `docs/INTEGRATION-README.md` | How the two apps sync and how to deploy them. |

Two views of the **same** eight-bridge network:

```
rail.html        (dispatcher / network scale)
   br1 Congaree  = BASCULE  ──┐
   br2 Cooper    = SWING    ──┤  same assets, two levels of fidelity
        │                     ▼
trainer.html     (maintainer + attacker + defender scale)
   Congaree River Bridge (bascule)  — every lock, brake, limit, register
   Cooper  River Bridge (swing)     — end lifts, wedges, rail locks, pivot
```

---

## Features

- **Two bridge types, modeled mechanically.** Bascule (vertical rotation about a trunnion, balanced
  by a counterweight) and swing (horizontal rotation about a center pivot, ends jacked onto live-load
  bearings when closed). Each subsystem is a discrete state machine with its own damage model.
- **A real Modbus attack surface.** Command coils, forcible output coils, holding registers, and
  spoofable input registers — the three data classes that carry the entire lesson.
- **Consequence-accurate physics.** Drive against engaged locks → stripped rack/pinion. Spoof
  lock-released feedback → the "safe" command path shears the locks. Defeat a limit switch →
  over-travel into the end stops. Open under load → catastrophe.
- **Live two-way sync.** Open or close Congaree/Cooper in either app and the other mirrors it,
  entirely browser-local (no backend).
- **Guided ICS attack scenarios**, each tagged with ATT&CK for ICS techniques, each with a detection
  signature and the independent safety control that would have stopped it.
- **100% offline, zero dependencies.** Vanilla HTML/CSS/JS/SVG, system fonts, no CDNs, no build step.
  Runs from any static file server in an air-gapped environment.

---

## The Modbus map (the heart of the lesson)

Every mechanical subsystem is wired to a Modbus point. Three classes, three different lessons:

| Class | Example points | What writing it teaches |
|---|---|---|
| **Command coils** `0000x` | `OPEN_CMD`, `CLOSE_CMD`, `STOP_CMD` | Honored with no authentication, but the PLC still runs its interlocks → **unauthorized but non-destructive** (T0855). |
| **Output coils** `001xx` | `MOTOR_RAISE`, `BRAKE_RELEASE`, `SPANLOCK_RELEASE`, `ENDLIFT_RETRACT` | Forcing a physical output **bypasses the interlocks** → mechanical, unrecoverable damage (T0831). |
| **Input registers** `300xx` | `POS_ANGLE`, `MOTOR_CURRENT`, `SEATED_LS`, `LOCK_STATUS`, `SPAN_OCCUPIED` | Spoofing a sensor makes even the *safe* command path destructive — the Stuxnet pattern (T0856 / T0832). |
| **Holding registers** `4000x` | `DRIVE_SPEED` | Parameter manipulation (T0836). |

The network console speaks Modbus-flavored commands:

```
scan                       dump every point + live value
read  ireg 30001           position; 30002 current; 30005 lock feedback
write coil 00001 1         OPEN_CMD  (PLC-validated → SAFE)
write coil 00101 1         force MOTOR_RAISE (bypasses PLC → can break things)
spoof ireg 30005 1         report span lock released while physically engaged
unforce all  /  clearspoof all     undo forces / spoofs
```

---

## Training scenarios

| # | Scenario | ATT&CK for ICS | Outcome |
|---|---|---|---|
| 1 | Reconnaissance — enumerate the field device | T0846, T0888 | Full control surface revealed; zero auth |
| 2 | Unauthorized OPEN via command coil | T0855 | Bridge opens safely but without authorization |
| 3 | Output forcing — drive against the locks | T0831, T0821 | Stall current, no motion, rack/pinion stripped |
| 4 | Sensor spoofing — lie to the interlock | T0856, T0832 | "Safe" sequence drives into engaged locks |
| 5 | Swing bridge — rotate on the jacks | T0831 | End-lift machinery sheared |
| 6 | Defeat the limit — over-travel the span | T0856, T0879 | Span driven past travel into the end stops |
| 7 | Open under load — catastrophe | T0879, T0880 | Span lifted under a train |

Each scenario runs from the in-app **Training Scenarios** panel and prints its steps into the console
so students can watch the attack execute, then read the lesson and detection signature.

---

## Quick start

TrainTracks is static files. Serve them from any web server **on a single origin** (the sync uses
`localStorage` + `BroadcastChannel`, which are origin-scoped).

```bash
# from the repo root
python3 -m http.server --bind 0.0.0.0 8080
```

Then browse to `http://<host>:8080/` and pick an app. Open both in separate tabs to see the live
Congaree/Cooper sync.

> **Do not use `file://`.** Chromium treats file pages as opaque origins and won't share state
> between two files. Always serve over HTTP (any static server works offline).

### Persistent deploy (systemd + /var/www/html)

```bash
sudo cp index.html rail.html trainer.html /var/www/html/
sudo chown www-data:www-data /var/www/html/*.html
```

`/etc/systemd/system/bridge.service`:

```ini
[Unit]
Description=TrainTracks ICS/SCADA Bridge Lab
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/www/html
ExecStart=/usr/bin/python3 -m http.server --bind 0.0.0.0 8080
Restart=on-failure
User=www-data

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload && sudo systemctl enable --now bridge.service
```

---

## Repository layout

```
TrainTracks/
├── index.html                       # launcher
├── rail.html                        # Donovia Rail Network Control (dispatcher HMI)
├── trainer.html                     # Bridge Mechanical & SCADA Trainer
├── docs/
│   ├── BRIDGE-MECHANICAL-ANALYSIS.md
│   └── INTEGRATION-README.md
├── deploy/
│   └── bridge.service               # optional systemd unit
└── README.md
```

---

## How the sync works

Both pages share bridge open/close state two ways, all browser-local:

1. **`localStorage`** key `scrail_bridge_sync_v1` holds the latest snapshot per bridge — the source
   of truth a freshly loaded tab reads on startup.
2. **`BroadcastChannel('scrail_bridges')`** pushes each change to other open tabs instantly, with a
   `storage`-event fallback.

Only `open / opening / closed / closing` crosses the boundary. Mechanical damage, forced coils, and
spoofed sensors stay local to the trainer — by design. (A nice teaching beat: an output-forcing
attack that destroys the drive train doesn't change the dispatcher's open/closed picture at all,
which is exactly why HMI-level monitoring misses field-level attacks.) Origin-tagged messages and
consistency guards prevent feedback loops.

---

## Suggested lab flow (~90 min)

1. **Brief** — `docs/BRIDGE-MECHANICAL-ANALYSIS.md` §1–§4: bascule vs swing mechanics.
2. **Normal ops** — drive Congaree and Cooper open/close from the HMI; watch the trainer mirror and
   name each subsystem as it actuates.
3. **The wire** — trainer console → `scan`; inventory the three register classes.
4. **Attacks** — run scenarios 1→7; after each, articulate what was written, why the PLC did/didn't
   stop it, what broke, and what the defender would have seen.
5. **Defense** — `docs/BRIDGE-MECHANICAL-ANALYSIS.md` §6: map each attack to its detection signature
   and the independent (non-PLC) safety control that stops it.

---

## Scope & intended use

TrainTracks is a **defensive training simulator**. It contains no real exploit code, no live protocol
stack, and no tooling that touches an actual device — it is a single-page model of an idealized
bridge controller built to teach detection and resilient design. The "attack" scenarios exist to make
the defensive lessons concrete. Use it in authorized training environments only. The geography and
the "Donovia" naming follow the Army's Decisive Action Training Environment convention; any resemblance
to a specific real bridge or control system is incidental.

---

## Roadmap

- Merge the deep model directly into `rail.html` so opening a bridge on the dispatcher map runs the
  full subsystem sequence and exposes the Modbus console in the control panel.
- Companion blue-team artifacts: Sigma rules / KQL hunts for the anomalies each scenario produces
  (out-of-sequence commands, forced I/O, position-vs-command deviation, sensor plausibility).
- Swap the map geometry for a fictional Donovian region.
- The remaining six bridges modeled at full fidelity.

---

## Built with

Vanilla HTML, CSS, JavaScript, and SVG. No frameworks, no build tooling, no external assets. Designed
to run in an isolated, air-gapped lab.

## License

MIT — see [`LICENSE`](LICENSE). Educational use encouraged; attribution appreciated.
